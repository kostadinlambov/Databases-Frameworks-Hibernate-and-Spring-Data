package p10_Beer_Counter;

public class BeerCounter {

    public static int beerInStock = 0;
    public static int beersDrankCount = 0;
}
