package p08_Vehicles;

public interface Vehicle {

    void drive(double distance);

    void refuel(double liters);

}
