package p05_Border_Control;

public interface Identifiable {
   void checkId(String id);
}
