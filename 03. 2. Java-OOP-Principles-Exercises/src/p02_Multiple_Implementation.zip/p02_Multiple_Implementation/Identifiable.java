package p02_Multiple_Implementation;

public interface Identifiable {
    String getId();
}
