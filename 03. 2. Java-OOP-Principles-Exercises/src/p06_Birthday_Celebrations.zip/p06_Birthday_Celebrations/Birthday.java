package p06_Birthday_Celebrations;

public interface Birthday {
    void checkYear(String year);
}
