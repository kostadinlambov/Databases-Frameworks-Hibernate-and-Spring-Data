package p06_Birthday_Celebrations;

public interface Identifiable {
   void checkId(String id);
}
