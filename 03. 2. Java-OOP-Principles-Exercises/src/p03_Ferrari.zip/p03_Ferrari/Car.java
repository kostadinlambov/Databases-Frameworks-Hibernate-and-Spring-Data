package p03_Ferrari;

public interface Car {

    String getModel();

    String getDriverName();

    String useBrakes();

    String useGasPedal();
}
