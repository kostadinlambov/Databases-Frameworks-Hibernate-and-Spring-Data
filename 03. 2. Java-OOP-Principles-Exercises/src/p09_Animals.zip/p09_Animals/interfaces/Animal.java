package p09_Animals.interfaces;

public interface Animal extends SoundProducible {
}
