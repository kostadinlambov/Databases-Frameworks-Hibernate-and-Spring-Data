package p09_Animals.interfaces;

public interface SoundProducible {
    void produceSound();
}
