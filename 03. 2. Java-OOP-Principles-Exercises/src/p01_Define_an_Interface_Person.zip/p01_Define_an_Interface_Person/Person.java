package p01_Define_an_Interface_Person;

public interface Person {
    String getName();

    int getAge();
}
