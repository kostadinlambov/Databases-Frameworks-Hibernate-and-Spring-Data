package p04_Telephony;

public interface Browsable {
    void browse(String url);
}
