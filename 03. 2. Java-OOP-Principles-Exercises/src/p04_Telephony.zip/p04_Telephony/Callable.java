package p04_Telephony;

public interface Callable {

    void call(String number);
}
