package p10_Group_by_Group;


public class Person {
    private String name;
    private Integer group;

    public Person(String name, Integer group) {
        this.name = name;
        this.group = group;
    }

    public String getName() {
        return this.name;
    }

    public Integer getGroup() {
        return this.group;
    }
}
