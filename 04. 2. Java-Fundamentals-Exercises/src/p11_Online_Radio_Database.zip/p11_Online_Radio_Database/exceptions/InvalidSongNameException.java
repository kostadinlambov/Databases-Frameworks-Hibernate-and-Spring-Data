package p11_Online_Radio_Database.exceptions;

public class InvalidSongNameException extends InvalidSongException {

    public InvalidSongNameException(String message) {
        super(message);
    }
}
