package p11_Online_Radio_Database.exceptions;

public class InvalidSongLengthException extends InvalidSongException {

    public InvalidSongLengthException(String message) {
        super(message);
    }
}
